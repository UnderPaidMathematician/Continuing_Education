import torch
import os
import pandas as pd


# Model
model = torch.hub.load('ultralytics/yolov5', 'yolov5s', pretrained=True)

# Images
imgPaths = []  # batch of images

# Gets all images in the path and builds a list of paths.
d = "C:\\Users\\jason\\Documents\\GitHub\\Continuing_Education\\Yolo5\\Data"

for root, dirs, files in os.walk(d):
    for file in files:
        if file.endswith(".jpg"):
             imgPaths.append(os.path.join(root, file))

# Noticed an odd issue where we lose the order that the images had origionally. Here is my fix. 
myData = pd.DataFrame(columns=["Id","Path"])

# Building a sortable index
for img in imgPaths:
    myData = myData.append({"Id": int(str(img).split(".")[0].split("e")[-1]), "Path": img}, ignore_index=True)

# Sort by ID
myData = myData.sort_values(by=["Id"])


for i in myData["Path"]:
# Inference
    results = model(i)

    # Results
    results.print()
    results.save()  # or .show()

    results.xyxy[0]  # img1 predictions (tensor)
    results.pandas().xyxy[0]  # img1 predictions (pandas)